two models for the import test
